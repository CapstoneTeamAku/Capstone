const databaseConfig = {
    host : '127.0.0.1' ,
    port : 3306,
    user : 'root' ,
    password : 'Helios2842!@' ,
    database : 'user_202305',
    waitForConnections : true ,
    connectionLimit : 10,
    queueLimit : 0
}

module.exports = databaseConfig;